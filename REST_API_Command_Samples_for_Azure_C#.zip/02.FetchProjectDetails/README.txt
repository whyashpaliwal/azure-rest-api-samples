Fetching Project data//

requst URL: https://dev.azure.com/TopTeamIntegration/_apis/projects/b473305b-d63e-451f-9455-b289ab029261
(got this URL from project URL response got from authenticating user)

response JSON:  (we get project detail fields )

{
  "id": "b473305b-d63e-451f-9455-b289ab029261",
  "name": "TEMP",
  "url": "https://dev.azure.com/TopTeamIntegration/_apis/projects/b473305b-d63e-451f-9455-b289ab029261",
  "state": "wellFormed",
  "revision": 19,
  "_links": {
    "self": {
      "href": "https://dev.azure.com/TopTeamIntegration/_apis/projects/b473305b-d63e-451f-9455-b289ab029261"
    },
    "collection": {
      "href": "https://dev.azure.com/TopTeamIntegration/_apis/projectCollections/c489fc85-13fe-47b3-9bc0-6c384e54c896"
    },
    "web": {
      "href": "https://dev.azure.com/TopTeamIntegration/TEMP"
    }
  },
  "visibility": "private",
  "defaultTeam": {
    "id": "d22f16e3-b77a-437e-893b-f68419b5a6fc",
    "name": "TEMP Team",
    "url": "https://dev.azure.com/TopTeamIntegration/_apis/projects/b473305b-d63e-451f-9455-b289ab029261/teams/d22f16e3-b77a-437e-893b-f68419b5a6fc"
  },
  "lastUpdateTime": "2020-06-30T13:27:36.16Z"
}